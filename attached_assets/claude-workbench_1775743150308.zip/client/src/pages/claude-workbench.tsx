import { useState, useRef, useCallback, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import {
  Terminal, FolderTree, Eye, GitBranch, Database, Shield,
  Key, Activity, ChevronRight, ChevronDown, File, Folder,
  RefreshCw, Play, Search, Copy, Loader2, Server,
  Clock, HardDrive, Cpu, MemoryStick, AlertTriangle,
  CheckCircle2, XCircle, FileCode, GitCommit, Trash2,
  Sparkles, Send, Square, User, Bot, ExternalLink,
  Globe, Lock, Code2, PanelLeftClose, PanelLeft,
  Puzzle, Download, DownloadCloud, Power, Zap,
  Brain, Target, ChevronUp, Bug,
} from "lucide-react";

type ShellEntry = { command: string; stdout: string; stderr: string; exitCode: number; timestamp: number };
type FileItem = { name: string; type: "file" | "directory"; path: string; size?: number };

function formatBytes(bytes: number) {
  if (bytes === 0) return "0 B";
  const k = 1024;
  const sizes = ["B", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + " " + sizes[i];
}

function formatUptime(seconds: number) {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  return `${h}h ${m}m`;
}

function ShellPanel() {
  const { toast } = useToast();
  const [input, setInput] = useState("");
  const [history, setHistory] = useState<ShellEntry[]>([]);
  const [cmdHistory, setCmdHistory] = useState<string[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const shellMutation = useMutation({
    mutationFn: async (command: string) => {
      const res = await apiRequest("POST", "/api/workbench/shell", { command });
      return res.json();
    },
    onSuccess: (data, command) => {
      setHistory(h => [...h, { command, ...data, timestamp: Date.now() }]);
      setCmdHistory(h => [command, ...h.slice(0, 49)]);
      setHistoryIndex(-1);
      setTimeout(() => scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight }), 50);
    },
    onError: (e: any) => toast({ title: "Shell error", description: e.message, variant: "destructive" }),
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;
    if (input.trim() === "clear") { setHistory([]); setInput(""); return; }
    shellMutation.mutate(input.trim());
    setInput("");
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "ArrowUp") {
      e.preventDefault();
      if (historyIndex < cmdHistory.length - 1) {
        const newIdx = historyIndex + 1;
        setHistoryIndex(newIdx);
        setInput(cmdHistory[newIdx]);
      }
    } else if (e.key === "ArrowDown") {
      e.preventDefault();
      if (historyIndex > 0) {
        const newIdx = historyIndex - 1;
        setHistoryIndex(newIdx);
        setInput(cmdHistory[newIdx]);
      } else {
        setHistoryIndex(-1);
        setInput("");
      }
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#1e1e2e] rounded-lg overflow-hidden" onClick={() => inputRef.current?.focus()}>
      <div className="flex items-center justify-between px-3 py-1.5 bg-[#181825] border-b border-[#313244]">
        <div className="flex items-center gap-2">
          <Terminal className="h-3.5 w-3.5 text-green-400" />
          <span className="text-xs text-[#cdd6f4] font-mono">Shell</span>
        </div>
        <Button variant="ghost" size="sm" className="h-6 px-2 text-[#6c7086] hover:text-[#cdd6f4]" onClick={() => setHistory([])} data-testid="button-clear-shell">
          <Trash2 className="h-3 w-3" />
        </Button>
      </div>
      <ScrollArea className="flex-1 p-2" ref={scrollRef}>
        <div className="font-mono text-xs space-y-1">
          {history.length === 0 && (
            <div className="text-[#6c7086] py-4 text-center">Type a command to get started. Use arrow keys for history.</div>
          )}
          {history.map((entry, i) => (
            <div key={i} className="mb-2">
              <div className="flex items-center gap-1">
                <span className="text-green-400">$</span>
                <span className="text-[#cdd6f4]">{entry.command}</span>
              </div>
              {entry.stdout && <pre className="text-[#a6adc8] whitespace-pre-wrap break-all ml-3 mt-0.5">{entry.stdout}</pre>}
              {entry.stderr && <pre className="text-[#f38ba8] whitespace-pre-wrap break-all ml-3 mt-0.5">{entry.stderr}</pre>}
            </div>
          ))}
          {shellMutation.isPending && (
            <div className="flex items-center gap-2 text-[#89b4fa]">
              <Loader2 className="h-3 w-3 animate-spin" />
              <span>Running...</span>
            </div>
          )}
        </div>
      </ScrollArea>
      <form onSubmit={handleSubmit} className="flex items-center gap-1 px-2 py-1.5 border-t border-[#313244] bg-[#181825]">
        <span className="text-green-400 font-mono text-xs">$</span>
        <input
          ref={inputRef}
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          className="flex-1 bg-transparent text-[#cdd6f4] font-mono text-xs outline-none placeholder:text-[#6c7086]"
          placeholder="Enter command..."
          disabled={shellMutation.isPending}
          data-testid="input-shell-command"
          autoFocus
        />
      </form>
    </div>
  );
}

function FileExplorerPanel() {
  const [currentPath, setCurrentPath] = useState(".");
  const [selectedFile, setSelectedFile] = useState<string | null>(null);
  const [expandedDirs, setExpandedDirs] = useState<Set<string>>(new Set());

  const { data, isLoading, refetch } = useQuery<any>({
    queryKey: ["/api/workbench/files", currentPath],
    queryFn: async () => {
      const res = await fetch(`/api/workbench/files?path=${encodeURIComponent(currentPath)}`, { credentials: "include" });
      return res.json();
    },
  });

  const { data: fileContent, isLoading: contentLoading } = useQuery<any>({
    queryKey: ["/api/workbench/file-content", selectedFile],
    queryFn: async () => {
      const res = await fetch(`/api/workbench/file-content?path=${encodeURIComponent(selectedFile!)}`, { credentials: "include" });
      return res.json();
    },
    enabled: !!selectedFile,
  });

  const items: FileItem[] = data?.items || [];
  const breadcrumbs = currentPath === "." ? ["root"] : ["root", ...currentPath.split("/").filter(Boolean)];

  const handleClick = (item: FileItem) => {
    if (item.type === "directory") {
      setCurrentPath(item.path || item.name);
      setSelectedFile(null);
    } else {
      setSelectedFile(item.path);
    }
  };

  const getFileIcon = (name: string) => {
    const ext = name.split(".").pop()?.toLowerCase();
    if (["ts", "tsx", "js", "jsx"].includes(ext || "")) return <FileCode className="h-3.5 w-3.5 text-blue-400" />;
    if (["json", "yaml", "yml", "toml"].includes(ext || "")) return <FileCode className="h-3.5 w-3.5 text-yellow-400" />;
    if (["md", "txt", "log"].includes(ext || "")) return <File className="h-3.5 w-3.5 text-gray-400" />;
    if (["css", "scss"].includes(ext || "")) return <FileCode className="h-3.5 w-3.5 text-pink-400" />;
    if (["html"].includes(ext || "")) return <FileCode className="h-3.5 w-3.5 text-orange-400" />;
    return <File className="h-3.5 w-3.5 text-muted-foreground" />;
  };

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between px-3 py-1.5 border-b">
        <div className="flex items-center gap-1 text-xs text-muted-foreground overflow-x-auto">
          {breadcrumbs.map((crumb, i) => (
            <span key={i} className="flex items-center gap-0.5">
              {i > 0 && <ChevronRight className="h-3 w-3" />}
              <button
                className="hover:text-foreground transition-colors"
                onClick={() => {
                  if (i === 0) setCurrentPath(".");
                  else setCurrentPath(breadcrumbs.slice(1, i + 1).join("/"));
                  setSelectedFile(null);
                }}
                data-testid={`button-breadcrumb-${i}`}
              >
                {crumb}
              </button>
            </span>
          ))}
        </div>
        <Button variant="ghost" size="sm" className="h-6 px-1.5" onClick={() => refetch()} data-testid="button-refresh-files">
          <RefreshCw className="h-3 w-3" />
        </Button>
      </div>
      <div className="flex flex-1 min-h-0">
        <ScrollArea className="w-1/3 border-r">
          <div className="p-1">
            {currentPath !== "." && (
              <button
                className="w-full text-left px-2 py-1 text-xs hover:bg-muted rounded flex items-center gap-1.5"
                onClick={() => {
                  const parts = currentPath.split("/");
                  parts.pop();
                  setCurrentPath(parts.length ? parts.join("/") : ".");
                  setSelectedFile(null);
                }}
                data-testid="button-dir-up"
              >
                <Folder className="h-3.5 w-3.5 text-yellow-500" />
                <span className="text-muted-foreground">..</span>
              </button>
            )}
            {isLoading ? (
              <div className="p-2 space-y-1">{[1,2,3,4].map(i => <Skeleton key={i} className="h-5 w-full" />)}</div>
            ) : (
              items.map(item => (
                <button
                  key={item.path}
                  className={`w-full text-left px-2 py-1 text-xs hover:bg-muted rounded flex items-center gap-1.5 ${selectedFile === item.path ? "bg-muted" : ""}`}
                  onClick={() => handleClick(item)}
                  data-testid={`button-file-${item.name}`}
                >
                  {item.type === "directory" ? (
                    <Folder className="h-3.5 w-3.5 text-yellow-500" />
                  ) : getFileIcon(item.name)}
                  <span className="truncate flex-1">{item.name}</span>
                  {item.size !== undefined && <span className="text-[10px] text-muted-foreground">{formatBytes(item.size)}</span>}
                </button>
              ))
            )}
          </div>
        </ScrollArea>
        <ScrollArea className="flex-1">
          {selectedFile ? (
            contentLoading ? (
              <div className="p-4 space-y-2"><Skeleton className="h-4 w-3/4" /><Skeleton className="h-4 w-1/2" /><Skeleton className="h-4 w-5/6" /></div>
            ) : fileContent?.error ? (
              <div className="p-4 text-sm text-destructive">{fileContent.error}</div>
            ) : (
              <div className="relative">
                <div className="flex items-center justify-between px-3 py-1 bg-muted/50 border-b sticky top-0">
                  <span className="text-xs font-mono text-muted-foreground">{selectedFile}</span>
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] text-muted-foreground">{formatBytes(fileContent?.size || 0)}</span>
                    <Button variant="ghost" size="sm" className="h-5 px-1" onClick={() => navigator.clipboard.writeText(fileContent?.content || "")} data-testid="button-copy-file">
                      <Copy className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
                <pre className="p-3 text-xs font-mono whitespace-pre-wrap break-all text-foreground">{fileContent?.content}</pre>
              </div>
            )
          ) : (
            <div className="p-8 text-center text-sm text-muted-foreground">
              <FileCode className="h-8 w-8 mx-auto mb-2 text-muted-foreground/30" />
              Select a file to view its contents
            </div>
          )}
        </ScrollArea>
      </div>
    </div>
  );
}

function PreviewPanel({ selectedProject }: { selectedProject?: SelectedProject }) {
  const { toast } = useToast();
  const [url, setUrl] = useState("");
  const [currentUrl, setCurrentUrl] = useState(`https://${window.location.host}`);
  const [publishing, setPublishing] = useState(false);
  const [deployStatus, setDeployStatus] = useState<"idle" | "checking" | "healthy" | "unhealthy">("idle");
  const prevProjectId = useRef<string | null>(null);

  useEffect(() => {
    if (selectedProject?.deploymentUrl && selectedProject.id !== prevProjectId.current) {
      prevProjectId.current = selectedProject.id;
      setCurrentUrl(selectedProject.deploymentUrl);
      setUrl(selectedProject.deploymentUrl);
    } else if (!selectedProject && prevProjectId.current) {
      prevProjectId.current = null;
      setCurrentUrl(`https://${window.location.host}`);
      setUrl("");
    }
  }, [selectedProject]);

  const checkDeployment = useCallback(async () => {
    if (!selectedProject?.id) return;
    setDeployStatus("checking");
    try {
      const res = await apiRequest("POST", `/api/replit-projects/${selectedProject.id}/check-deployment`);
      const data = await res.json();
      setDeployStatus(data.deploymentStatus === "healthy" ? "healthy" : "unhealthy");
    } catch {
      setDeployStatus("unhealthy");
    }
  }, [selectedProject?.id]);

  const handlePublish = useCallback(async () => {
    if (!selectedProject) return;
    setPublishing(true);
    try {
      const res = await apiRequest("POST", "/api/vps/deploy", { appFolder: selectedProject.slug });
      const data = await res.json();
      toast({ title: "Deploy triggered", description: data.message || `Deploying ${selectedProject.title}...` });
      setTimeout(() => checkDeployment(), 10000);
    } catch (err: any) {
      toast({ title: "Deploy failed", description: err.message, variant: "destructive" });
    } finally {
      setPublishing(false);
    }
  }, [selectedProject, toast, checkDeployment]);

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center gap-2 px-2 py-1.5 border-b">
        <Eye className="h-3.5 w-3.5 text-muted-foreground" />
        <form className="flex-1 flex gap-1" onSubmit={e => { e.preventDefault(); if (url) setCurrentUrl(url); }}>
          <Input
            value={url}
            onChange={e => setUrl(e.target.value)}
            placeholder={currentUrl}
            className="h-7 text-xs font-mono"
            data-testid="input-preview-url"
          />
          <Button type="submit" variant="outline" size="sm" className="h-7 px-2" data-testid="button-preview-go">
            <Play className="h-3 w-3" />
          </Button>
        </form>
        <Button variant="outline" size="sm" className="h-7 px-2" onClick={() => setCurrentUrl(currentUrl + "?" + Date.now())} data-testid="button-preview-refresh">
          <RefreshCw className="h-3 w-3" />
        </Button>
        {selectedProject && (
          <>
            <Separator orientation="vertical" className="h-5" />
            <Button
              variant="outline"
              size="sm"
              className="h-7 px-2 text-xs gap-1"
              onClick={checkDeployment}
              disabled={deployStatus === "checking"}
              data-testid="button-check-deploy"
            >
              {deployStatus === "checking" ? (
                <Loader2 className="h-3 w-3 animate-spin" />
              ) : deployStatus === "healthy" ? (
                <CheckCircle2 className="h-3 w-3 text-emerald-500" />
              ) : deployStatus === "unhealthy" ? (
                <XCircle className="h-3 w-3 text-red-500" />
              ) : (
                <Globe className="h-3 w-3" />
              )}
              Status
            </Button>
            <Button
              size="sm"
              className="h-7 px-3 text-xs gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white"
              onClick={handlePublish}
              disabled={publishing}
              data-testid="button-publish-project"
            >
              {publishing ? (
                <Loader2 className="h-3 w-3 animate-spin" />
              ) : (
                <Globe className="h-3 w-3" />
              )}
              Publish
            </Button>
          </>
        )}
      </div>
      <div className="flex-1">
        <iframe src={currentUrl} className="w-full h-full border-0" title="Preview" data-testid="iframe-preview" />
      </div>
    </div>
  );
}

function GitPanel() {
  const { toast } = useToast();
  const { data, isLoading, refetch } = useQuery<any>({ queryKey: ["/api/workbench/git-status"] });

  const gitMutation = useMutation({
    mutationFn: async (command: string) => {
      const res = await apiRequest("POST", "/api/workbench/git", { command });
      return res.json();
    },
    onSuccess: (data) => {
      toast({ title: "Git command executed" });
      refetch();
    },
    onError: (e: any) => toast({ title: "Git error", description: e.message, variant: "destructive" }),
  });

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between px-3 py-1.5 border-b">
        <div className="flex items-center gap-2">
          <GitBranch className="h-3.5 w-3.5 text-orange-400" />
          <span className="text-xs font-medium">Git</span>
          {data?.currentBranch && <Badge variant="outline" className="text-[10px]" data-testid="badge-git-branch">{data.currentBranch}</Badge>}
        </div>
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="sm" className="h-6 px-2 text-xs" onClick={() => gitMutation.mutate("git pull")} disabled={gitMutation.isPending} data-testid="button-git-pull">Pull</Button>
          <Button variant="ghost" size="sm" className="h-6 px-2 text-xs" onClick={() => gitMutation.mutate("git fetch")} disabled={gitMutation.isPending} data-testid="button-git-fetch">Fetch</Button>
          <Button variant="ghost" size="sm" className="h-6 px-1.5" onClick={() => refetch()} data-testid="button-git-refresh"><RefreshCw className="h-3 w-3" /></Button>
        </div>
      </div>
      <ScrollArea className="flex-1">
        {isLoading ? (
          <div className="p-3 space-y-2">{[1,2,3].map(i => <Skeleton key={i} className="h-6 w-full" />)}</div>
        ) : data?.error ? (
          <div className="p-4 text-sm text-destructive">{data.error}</div>
        ) : (
          <div className="p-2 space-y-3">
            {data?.changes?.length > 0 && (
              <div>
                <h4 className="text-xs font-medium text-muted-foreground mb-1 px-1">Changes ({data.changes.length})</h4>
                <div className="space-y-0.5">
                  {data.changes.map((c: any, i: number) => (
                    <div key={i} className="flex items-center gap-1.5 px-1 py-0.5 rounded text-xs hover:bg-muted" data-testid={`git-change-${i}`}>
                      <Badge variant="outline" className={`text-[9px] px-1 ${
                        c.status === "M" ? "text-yellow-500 border-yellow-500/30" :
                        c.status === "A" || c.status === "??" ? "text-green-500 border-green-500/30" :
                        c.status === "D" ? "text-red-500 border-red-500/30" : ""
                      }`}>{c.status}</Badge>
                      <span className="truncate font-mono text-[11px]">{c.file}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
            {data?.changes?.length === 0 && (
              <div className="text-xs text-center text-muted-foreground py-2">Working tree clean</div>
            )}
            <Separator />
            <div>
              <h4 className="text-xs font-medium text-muted-foreground mb-1 px-1">Recent Commits</h4>
              <div className="space-y-0.5">
                {data?.commits?.slice(0, 15).map((c: any, i: number) => (
                  <div key={i} className="flex items-start gap-1.5 px-1 py-1 rounded text-xs hover:bg-muted" data-testid={`git-commit-${i}`}>
                    <GitCommit className="h-3 w-3 mt-0.5 text-muted-foreground shrink-0" />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[11px]">{c.message}</p>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] text-muted-foreground font-mono">{c.hash?.substring(0, 7)}</span>
                        <span className="text-[10px] text-muted-foreground">{c.date}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            {data?.remotes?.length > 0 && (
              <>
                <Separator />
                <div>
                  <h4 className="text-xs font-medium text-muted-foreground mb-1 px-1">Remotes</h4>
                  {data.remotes.filter((r: any) => r.type === "fetch").map((r: any, i: number) => (
                    <div key={i} className="px-1 text-[11px] font-mono text-muted-foreground truncate">{r.name}: {r.url}</div>
                  ))}
                </div>
              </>
            )}
          </div>
        )}
      </ScrollArea>
    </div>
  );
}

function AgentActivityPanel() {
  const [expandedCommit, setExpandedCommit] = useState<string | null>(null);
  const [filter, setFilter] = useState<"all" | "agent" | "manual">("all");
  const { data, isLoading, refetch } = useQuery<any>({ queryKey: ["/api/workbench/agent-activity"] });

  const entries = (data?.entries || []).filter((e: any) => {
    if (filter === "agent") return e.isAgent;
    if (filter === "manual") return !e.isAgent;
    return true;
  });

  const formatDate = (iso: string) => {
    try {
      const d = new Date(iso);
      const now = new Date();
      const diff = now.getTime() - d.getTime();
      const mins = Math.floor(diff / 60000);
      if (mins < 1) return "just now";
      if (mins < 60) return `${mins}m ago`;
      const hrs = Math.floor(mins / 60);
      if (hrs < 24) return `${hrs}h ago`;
      const days = Math.floor(hrs / 24);
      if (days < 7) return `${days}d ago`;
      return d.toLocaleDateString();
    } catch { return iso; }
  };

  const statusLabel = (s: string) => {
    switch (s) {
      case "A": return { text: "added", cls: "text-green-500 border-green-500/30" };
      case "M": return { text: "modified", cls: "text-yellow-500 border-yellow-500/30" };
      case "D": return { text: "deleted", cls: "text-red-500 border-red-500/30" };
      case "R": return { text: "renamed", cls: "text-blue-500 border-blue-500/30" };
      default: return { text: s, cls: "text-muted-foreground" };
    }
  };

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between px-3 py-1.5 border-b">
        <div className="flex items-center gap-2">
          <Activity className="h-3.5 w-3.5 text-purple-400" />
          <span className="text-xs font-medium">Agent Activity</span>
          {data?.stats && (
            <Badge variant="outline" className="text-[10px]" data-testid="badge-agent-commit-count">
              {data.stats.agentCommits} agent / {data.stats.totalCommits} total
            </Badge>
          )}
        </div>
        <div className="flex items-center gap-1">
          <Button
            variant={filter === "all" ? "default" : "ghost"}
            size="sm"
            className="h-5 px-1.5 text-[10px]"
            onClick={() => setFilter("all")}
            data-testid="button-filter-all"
          >All</Button>
          <Button
            variant={filter === "agent" ? "default" : "ghost"}
            size="sm"
            className="h-5 px-1.5 text-[10px]"
            onClick={() => setFilter("agent")}
            data-testid="button-filter-agent"
          >Agent</Button>
          <Button
            variant={filter === "manual" ? "default" : "ghost"}
            size="sm"
            className="h-5 px-1.5 text-[10px]"
            onClick={() => setFilter("manual")}
            data-testid="button-filter-manual"
          >Manual</Button>
          <Button variant="ghost" size="sm" className="h-6 px-1.5" onClick={() => refetch()} data-testid="button-activity-refresh">
            <RefreshCw className="h-3 w-3" />
          </Button>
        </div>
      </div>

      {data?.stats && (
        <div className="flex items-center gap-3 px-3 py-1.5 border-b bg-muted/30">
          <div className="flex items-center gap-1">
            <Bot className="h-3 w-3 text-purple-400" />
            <span className="text-[10px] text-muted-foreground">{data.stats.agentCommits} agent changes</span>
          </div>
          <div className="flex items-center gap-1">
            <User className="h-3 w-3 text-blue-400" />
            <span className="text-[10px] text-muted-foreground">{data.stats.manualCommits} manual</span>
          </div>
          <div className="flex items-center gap-1">
            <FileCode className="h-3 w-3 text-green-400" />
            <span className="text-[10px] text-muted-foreground">{data.stats.filesChanged} files touched</span>
          </div>
        </div>
      )}

      <ScrollArea className="flex-1">
        {isLoading ? (
          <div className="p-3 space-y-2">{[1,2,3,4,5].map(i => <Skeleton key={i} className="h-10 w-full" />)}</div>
        ) : entries.length === 0 ? (
          <div className="p-4 text-sm text-center text-muted-foreground">No activity found</div>
        ) : (
          <div className="p-1">
            {entries.map((entry: any) => {
              const expanded = expandedCommit === entry.hash;
              return (
                <div key={entry.hash} className="border-b last:border-0" data-testid={`activity-entry-${entry.hash?.substring(0, 7)}`}>
                  <button
                    className="w-full flex items-start gap-2 px-2 py-1.5 text-left hover:bg-muted/50 transition-colors"
                    onClick={() => setExpandedCommit(expanded ? null : entry.hash)}
                    data-testid={`button-expand-${entry.hash?.substring(0, 7)}`}
                  >
                    <div className="mt-0.5 shrink-0">
                      {entry.isAgent ? (
                        <Bot className="h-3.5 w-3.5 text-purple-400" />
                      ) : (
                        <User className="h-3.5 w-3.5 text-blue-400" />
                      )}
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-xs leading-snug truncate">{entry.message}</p>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className="text-[10px] text-muted-foreground font-mono">{entry.hash?.substring(0, 7)}</span>
                        <span className="text-[10px] text-muted-foreground">{formatDate(entry.date)}</span>
                        {entry.files.length > 0 && (
                          <span className="text-[10px] text-muted-foreground">{entry.files.length} file{entry.files.length !== 1 ? "s" : ""}</span>
                        )}
                      </div>
                      {entry.body && (
                        <p className="text-[10px] text-muted-foreground mt-0.5 line-clamp-2">{entry.body}</p>
                      )}
                    </div>
                    {entry.files.length > 0 && (
                      <div className="shrink-0 mt-0.5">
                        {expanded ? <ChevronDown className="h-3 w-3 text-muted-foreground" /> : <ChevronRight className="h-3 w-3 text-muted-foreground" />}
                      </div>
                    )}
                  </button>
                  {expanded && entry.files.length > 0 && (
                    <div className="pl-7 pr-2 pb-2 space-y-0.5">
                      {entry.files.map((f: any, i: number) => {
                        const s = statusLabel(f.status);
                        return (
                          <div key={i} className="flex items-center gap-1.5 text-[11px]" data-testid={`activity-file-${i}`}>
                            <Badge variant="outline" className={`text-[9px] px-1 py-0 ${s.cls}`}>{s.text}</Badge>
                            <span className="font-mono truncate text-muted-foreground">{f.file}</span>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </ScrollArea>
    </div>
  );
}

function DatabasePanel() {
  const { toast } = useToast();
  const [query, setQuery] = useState("SELECT schemaname, relname as table_name, n_live_tup as row_count FROM pg_stat_user_tables ORDER BY n_live_tup DESC");
  const [results, setResults] = useState<any>(null);

  const { data: dbStats, isLoading: statsLoading, refetch } = useQuery<any>({ queryKey: ["/api/data-backups/db-stats"] });

  const queryMutation = useMutation({
    mutationFn: async (q: string) => {
      const res = await fetch(`/api/workbench/db-query?q=${encodeURIComponent(q)}`, { credentials: "include" });
      return res.json();
    },
    onSuccess: (data) => {
      if (data.error) { toast({ title: "Query error", description: data.error, variant: "destructive" }); return; }
      setResults(data);
    },
    onError: (e: any) => toast({ title: "Query failed", description: e.message, variant: "destructive" }),
  });

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between px-3 py-1.5 border-b">
        <div className="flex items-center gap-2">
          <Database className="h-3.5 w-3.5 text-blue-400" />
          <span className="text-xs font-medium">Database Explorer</span>
        </div>
        <div className="flex items-center gap-2">
          {dbStats && (
            <div className="flex items-center gap-2 text-[10px] text-muted-foreground">
              <span>{dbStats.totalTables} tables</span>
              <span>{dbStats.totalRows?.toLocaleString()} rows</span>
              <span>{dbStats.databaseSize}</span>
            </div>
          )}
          <Button variant="ghost" size="sm" className="h-6 px-1.5" onClick={() => refetch()} data-testid="button-db-refresh"><RefreshCw className="h-3 w-3" /></Button>
        </div>
      </div>
      <div className="p-2 border-b space-y-1.5">
        <Textarea
          value={query}
          onChange={e => setQuery(e.target.value)}
          className="font-mono text-xs min-h-[60px] resize-y"
          placeholder="SELECT * FROM ..."
          data-testid="input-db-query"
        />
        <div className="flex items-center gap-2">
          <Button size="sm" className="h-7 text-xs" onClick={() => queryMutation.mutate(query)} disabled={queryMutation.isPending || !query.trim()} data-testid="button-db-run">
            {queryMutation.isPending ? <Loader2 className="h-3 w-3 animate-spin mr-1" /> : <Play className="h-3 w-3 mr-1" />}
            Run Query
          </Button>
          {results && <span className="text-[10px] text-muted-foreground">{results.rowCount} rows returned</span>}
        </div>
      </div>
      <ScrollArea className="flex-1">
        {results?.rows?.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead className="bg-muted/50 sticky top-0">
                <tr>
                  {results.fields.map((f: string) => (
                    <th key={f} className="px-2 py-1.5 text-left font-medium text-muted-foreground border-b">{f}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {results.rows.map((row: any, i: number) => (
                  <tr key={i} className="hover:bg-muted/30 border-b border-border/50">
                    {results.fields.map((f: string) => (
                      <td key={f} className="px-2 py-1 font-mono text-[11px] max-w-[200px] truncate">{String(row[f] ?? "NULL")}</td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : results ? (
          <div className="p-4 text-center text-xs text-muted-foreground">No results</div>
        ) : statsLoading ? (
          <div className="p-3 space-y-1">{[1,2,3].map(i => <Skeleton key={i} className="h-5 w-full" />)}</div>
        ) : (
          <div className="p-2 space-y-0.5">
            {dbStats?.tables?.map((t: any, i: number) => (
              <button
                key={i}
                className="w-full text-left px-2 py-1 rounded text-xs hover:bg-muted flex items-center justify-between"
                onClick={() => { setQuery(`SELECT * FROM "${t.table_name}" LIMIT 50`); }}
                data-testid={`button-table-${t.table_name}`}
              >
                <span className="font-mono">{t.table_name}</span>
                <Badge variant="secondary" className="text-[9px]">{parseInt(t.row_count || t.rowCount || "0").toLocaleString()}</Badge>
              </button>
            ))}
          </div>
        )}
      </ScrollArea>
    </div>
  );
}

function SecurityPanel() {
  const { toast } = useToast();
  const [scanText, setScanText] = useState("");

  const { data: report, isLoading, refetch } = useQuery<any>({ queryKey: ["/api/security/report"] });

  const scanMutation = useMutation({
    mutationFn: async (text: string) => {
      const res = await apiRequest("POST", "/api/security/scan-text", { text });
      return res.json();
    },
    onSuccess: (data) => {
      toast({ title: data.findings?.length ? `${data.findings.length} finding(s)` : "No issues found" });
    },
    onError: (e: any) => toast({ title: "Scan failed", description: e.message, variant: "destructive" }),
  });

  const configScanMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/security/scan-config", {});
      return res.json();
    },
    onSuccess: (data) => {
      toast({ title: `Config scan: ${data.findings?.length || 0} finding(s)` });
      refetch();
    },
  });

  const sshScanMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/security/scan-ssh", {});
      return res.json();
    },
    onSuccess: (data) => {
      toast({ title: `SSH scan: ${data.findings?.length || 0} finding(s)` });
      refetch();
    },
  });

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between px-3 py-1.5 border-b">
        <div className="flex items-center gap-2">
          <Shield className="h-3.5 w-3.5 text-red-400" />
          <span className="text-xs font-medium">Security Scanner</span>
        </div>
        <Button variant="ghost" size="sm" className="h-6 px-1.5" onClick={() => refetch()} data-testid="button-security-refresh"><RefreshCw className="h-3 w-3" /></Button>
      </div>
      <div className="p-2 border-b space-y-1.5">
        <div className="flex gap-1.5">
          <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => configScanMutation.mutate()} disabled={configScanMutation.isPending} data-testid="button-scan-config">
            {configScanMutation.isPending && <Loader2 className="h-3 w-3 animate-spin mr-1" />} Scan Config
          </Button>
          <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => sshScanMutation.mutate()} disabled={sshScanMutation.isPending} data-testid="button-scan-ssh">
            {sshScanMutation.isPending && <Loader2 className="h-3 w-3 animate-spin mr-1" />} Scan SSH
          </Button>
        </div>
        <div className="flex gap-1">
          <Input
            value={scanText}
            onChange={e => setScanText(e.target.value)}
            className="h-7 text-xs"
            placeholder="Paste text to scan for secrets..."
            data-testid="input-scan-text"
          />
          <Button size="sm" className="h-7 px-2" onClick={() => scanMutation.mutate(scanText)} disabled={scanMutation.isPending || !scanText} data-testid="button-scan-text">
            <Search className="h-3 w-3" />
          </Button>
        </div>
      </div>
      <ScrollArea className="flex-1">
        {isLoading ? (
          <div className="p-3 space-y-2">{[1,2,3].map(i => <Skeleton key={i} className="h-8 w-full" />)}</div>
        ) : (
          <div className="p-2 space-y-2">
            {report?.summary && (
              <div className="grid grid-cols-3 gap-2">
                <div className="p-2 rounded bg-muted/50 text-center">
                  <div className="text-lg font-semibold" data-testid="text-security-critical">{report.summary.critical || 0}</div>
                  <div className="text-[10px] text-red-500">Critical</div>
                </div>
                <div className="p-2 rounded bg-muted/50 text-center">
                  <div className="text-lg font-semibold" data-testid="text-security-warnings">{report.summary.warnings || 0}</div>
                  <div className="text-[10px] text-yellow-500">Warnings</div>
                </div>
                <div className="p-2 rounded bg-muted/50 text-center">
                  <div className="text-lg font-semibold" data-testid="text-security-passed">{report.summary.passed || 0}</div>
                  <div className="text-[10px] text-green-500">Passed</div>
                </div>
              </div>
            )}
            {report?.findings?.map((f: any, i: number) => (
              <div key={i} className="p-2 rounded border text-xs space-y-1" data-testid={`security-finding-${i}`}>
                <div className="flex items-center gap-1.5">
                  {f.severity === "critical" ? <XCircle className="h-3.5 w-3.5 text-red-500" /> :
                   f.severity === "warning" ? <AlertTriangle className="h-3.5 w-3.5 text-yellow-500" /> :
                   <CheckCircle2 className="h-3.5 w-3.5 text-green-500" />}
                  <span className="font-medium">{f.title || f.type}</span>
                  <Badge variant="outline" className="text-[9px]">{f.severity}</Badge>
                </div>
                {f.description && <p className="text-muted-foreground text-[11px]">{f.description}</p>}
              </div>
            ))}
            {(!report?.findings || report.findings.length === 0) && !report?.summary && (
              <div className="p-4 text-center text-xs text-muted-foreground">
                <Shield className="h-8 w-8 mx-auto mb-2 text-muted-foreground/30" />
                Run a scan to see results
              </div>
            )}
          </div>
        )}
      </ScrollArea>
    </div>
  );
}

function EnvPanel() {
  const [search, setSearch] = useState("");
  const { data, isLoading, refetch } = useQuery<any>({ queryKey: ["/api/workbench/env"] });

  const vars = (data?.variables || []).filter((v: any) =>
    !search || v.key.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between px-3 py-1.5 border-b">
        <div className="flex items-center gap-2">
          <Key className="h-3.5 w-3.5 text-purple-400" />
          <span className="text-xs font-medium">Environment ({data?.count || 0})</span>
        </div>
        <Button variant="ghost" size="sm" className="h-6 px-1.5" onClick={() => refetch()} data-testid="button-env-refresh"><RefreshCw className="h-3 w-3" /></Button>
      </div>
      <div className="px-2 py-1.5 border-b">
        <div className="relative">
          <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-3 w-3 text-muted-foreground" />
          <Input value={search} onChange={e => setSearch(e.target.value)} className="h-7 text-xs pl-7" placeholder="Filter variables..." data-testid="input-env-search" />
        </div>
      </div>
      <ScrollArea className="flex-1">
        {isLoading ? (
          <div className="p-3 space-y-1">{[1,2,3,4].map(i => <Skeleton key={i} className="h-5 w-full" />)}</div>
        ) : (
          <div className="p-1">
            {vars.map((v: any, i: number) => (
              <div key={v.key} className="flex items-center gap-2 px-2 py-1 rounded hover:bg-muted text-xs" data-testid={`env-var-${v.key}`}>
                <span className="font-mono font-medium text-[11px] min-w-0 shrink-0">{v.key}</span>
                <span className="text-muted-foreground">=</span>
                <span className={`font-mono text-[11px] truncate ${v.sensitive ? "text-yellow-500" : "text-muted-foreground"}`}>{v.value}</span>
                {v.sensitive && <Key className="h-3 w-3 text-yellow-500 shrink-0" />}
              </div>
            ))}
          </div>
        )}
      </ScrollArea>
    </div>
  );
}

function ProcessPanel() {
  const { data, isLoading, refetch } = useQuery<any>({
    queryKey: ["/api/workbench/process-info"],
    refetchInterval: 10000,
  });

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between px-3 py-1.5 border-b">
        <div className="flex items-center gap-2">
          <Activity className="h-3.5 w-3.5 text-emerald-400" />
          <span className="text-xs font-medium">Process Info</span>
        </div>
        <Button variant="ghost" size="sm" className="h-6 px-1.5" onClick={() => refetch()} data-testid="button-process-refresh"><RefreshCw className="h-3 w-3" /></Button>
      </div>
      <ScrollArea className="flex-1">
        {isLoading ? (
          <div className="p-3 space-y-2">{[1,2,3].map(i => <Skeleton key={i} className="h-12 w-full" />)}</div>
        ) : data ? (
          <div className="p-3 space-y-3">
            <div className="grid grid-cols-2 gap-2">
              <div className="p-2 rounded bg-muted/50">
                <div className="flex items-center gap-1.5 text-[10px] text-muted-foreground mb-0.5"><Clock className="h-3 w-3" /> Uptime</div>
                <div className="text-sm font-semibold" data-testid="text-uptime">{formatUptime(data.uptime)}</div>
              </div>
              <div className="p-2 rounded bg-muted/50">
                <div className="flex items-center gap-1.5 text-[10px] text-muted-foreground mb-0.5"><Server className="h-3 w-3" /> Node</div>
                <div className="text-sm font-semibold" data-testid="text-node-version">{data.nodeVersion}</div>
              </div>
              <div className="p-2 rounded bg-muted/50">
                <div className="flex items-center gap-1.5 text-[10px] text-muted-foreground mb-0.5"><MemoryStick className="h-3 w-3" /> Heap Used</div>
                <div className="text-sm font-semibold">{formatBytes(data.memoryUsage?.heapUsed || 0)}</div>
              </div>
              <div className="p-2 rounded bg-muted/50">
                <div className="flex items-center gap-1.5 text-[10px] text-muted-foreground mb-0.5"><HardDrive className="h-3 w-3" /> RSS</div>
                <div className="text-sm font-semibold">{formatBytes(data.memoryUsage?.rss || 0)}</div>
              </div>
              <div className="p-2 rounded bg-muted/50">
                <div className="flex items-center gap-1.5 text-[10px] text-muted-foreground mb-0.5"><Cpu className="h-3 w-3" /> CPUs</div>
                <div className="text-sm font-semibold">{data.cpus}</div>
              </div>
              <div className="p-2 rounded bg-muted/50">
                <div className="flex items-center gap-1.5 text-[10px] text-muted-foreground mb-0.5"><HardDrive className="h-3 w-3" /> Free Mem</div>
                <div className="text-sm font-semibold">{formatBytes(data.freeMemory || 0)}</div>
              </div>
            </div>
            <Separator />
            <div className="space-y-1 text-xs">
              <div className="flex justify-between"><span className="text-muted-foreground">Platform</span><span className="font-mono">{data.platform} ({data.arch})</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">PID</span><span className="font-mono">{data.pid}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Hostname</span><span className="font-mono truncate ml-2">{data.hostname}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Load Avg</span><span className="font-mono">{data.loadAvg?.map((l: number) => l.toFixed(2)).join(", ")}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Heap Total</span><span className="font-mono">{formatBytes(data.memoryUsage?.heapTotal || 0)}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">External</span><span className="font-mono">{formatBytes(data.memoryUsage?.external || 0)}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Total Memory</span><span className="font-mono">{formatBytes(data.totalMemory || 0)}</span></div>
            </div>
          </div>
        ) : null}
      </ScrollArea>
    </div>
  );
}

type ClaudeMessage = {
  role: "user" | "assistant";
  content: string;
  timestamp: number;
  streaming?: boolean;
};

type SelectedProject = {
  id: string;
  title: string;
  slug: string;
  url?: string | null;
  deploymentUrl?: string | null;
  description?: string | null;
  language?: string | null;
} | null;

function ClaudeCodePanel({ selectedProject }: { selectedProject?: SelectedProject }) {
  const { toast } = useToast();
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<ClaudeMessage[]>([]);
  const [isStreaming, setIsStreaming] = useState(false);
  const [abortController, setAbortController] = useState<AbortController | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const scrollToBottom = useCallback(() => {
    setTimeout(() => scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight }), 50);
  }, []);

  const handleStop = useCallback(() => {
    if (abortController) {
      abortController.abort();
      setAbortController(null);
      setIsStreaming(false);
      setMessages(prev => prev.map(m => m.streaming ? { ...m, streaming: false, content: m.content + "\n\n[Stopped]" } : m));
    }
  }, [abortController]);

  const handleSubmit = useCallback(async () => {
    if (!input.trim() || isStreaming) return;
    const prompt = input.trim();
    setInput("");

    const userMsg: ClaudeMessage = { role: "user", content: prompt, timestamp: Date.now() };
    const assistantMsg: ClaudeMessage = { role: "assistant", content: "", timestamp: Date.now(), streaming: true };
    setMessages(prev => [...prev, userMsg, assistantMsg]);
    setIsStreaming(true);
    scrollToBottom();

    const controller = new AbortController();
    setAbortController(controller);

    try {
      const body: Record<string, any> = { prompt };
      if (selectedProject) {
        body.projectContext = {
          title: selectedProject.title,
          slug: selectedProject.slug,
          url: selectedProject.url,
          deploymentUrl: selectedProject.deploymentUrl,
          description: selectedProject.description,
          language: selectedProject.language,
        };
      }

      const res = await fetch("/api/workbench/claude-code", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
        credentials: "include",
        signal: controller.signal,
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({ error: "Request failed" }));
        throw new Error(err.error || `HTTP ${res.status}`);
      }

      const reader = res.body?.getReader();
      const decoder = new TextDecoder();

      if (reader) {
        let buffer = "";
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });

          const lines = buffer.split("\n");
          buffer = lines.pop() || "";

          for (const line of lines) {
            if (!line.startsWith("data: ")) continue;
            try {
              const data = JSON.parse(line.slice(6));
              if (data.type === "chunk") {
                setMessages(prev => {
                  const updated = [...prev];
                  const last = updated[updated.length - 1];
                  if (last?.streaming) {
                    updated[updated.length - 1] = { ...last, content: last.content + data.content };
                  }
                  return updated;
                });
                scrollToBottom();
              } else if (data.type === "stderr") {
                setMessages(prev => {
                  const updated = [...prev];
                  const last = updated[updated.length - 1];
                  if (last?.streaming) {
                    updated[updated.length - 1] = { ...last, content: last.content + data.content };
                  }
                  return updated;
                });
              } else if (data.type === "done") {
                setMessages(prev => prev.map(m => m.streaming ? { ...m, streaming: false } : m));
              } else if (data.type === "error") {
                setMessages(prev => prev.map(m => m.streaming ? { ...m, streaming: false, content: m.content + `\n\nError: ${data.content}` } : m));
              }
            } catch {}
          }
        }
      }
    } catch (err: any) {
      if (err.name === "AbortError") return;
      setMessages(prev => prev.map(m => m.streaming ? { ...m, streaming: false, content: `Error: ${err.message}` } : m));
      toast({ title: "Claude Code error", description: err.message, variant: "destructive" });
    } finally {
      setIsStreaming(false);
      setAbortController(null);
      setMessages(prev => prev.map(m => m.streaming ? { ...m, streaming: false } : m));
      scrollToBottom();
    }
  }, [input, isStreaming, scrollToBottom, toast, selectedProject]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#1e1e2e] rounded-lg overflow-hidden" onClick={() => textareaRef.current?.focus()}>
      <div className="flex items-center justify-between px-3 py-1.5 bg-[#181825] border-b border-[#313244]">
        <div className="flex items-center gap-2">
          <Sparkles className="h-3.5 w-3.5 text-purple-400" />
          <span className="text-xs text-[#cdd6f4] font-mono">Claude Code</span>
          <Badge variant="outline" className="text-[9px] h-4 border-purple-500/30 text-purple-400">v2.1</Badge>
          {selectedProject && (
            <Badge variant="outline" className="text-[9px] h-4 border-emerald-500/30 text-emerald-400 max-w-[200px] truncate" data-testid="badge-active-project">
              <Code2 className="h-2.5 w-2.5 mr-1 shrink-0" />
              {selectedProject.title}
            </Badge>
          )}
        </div>
        <Button
          variant="ghost"
          size="sm"
          className="h-6 px-2 text-[#6c7086] hover:text-[#cdd6f4]"
          onClick={() => setMessages([])}
          data-testid="button-clear-claude"
        >
          <Trash2 className="h-3 w-3" />
        </Button>
      </div>

      <ScrollArea className="flex-1 p-3" ref={scrollRef}>
        <div className="space-y-3">
          {messages.length === 0 && (
            <div className="text-center py-8 space-y-3">
              <div className="flex justify-center">
                <div className="h-10 w-10 rounded-full bg-purple-500/10 flex items-center justify-center">
                  <Sparkles className="h-5 w-5 text-purple-400" />
                </div>
              </div>
              <div>
                <p className="text-[#cdd6f4] text-sm font-medium">Claude Code Terminal</p>
                {selectedProject ? (
                  <p className="text-[#6c7086] text-xs mt-1">Working on <span className="text-emerald-400 font-medium">{selectedProject.title}</span>. Ask Claude about this project.</p>
                ) : (
                  <p className="text-[#6c7086] text-xs mt-1">Select a project from the sidebar, or ask about this workspace.</p>
                )}
              </div>
              <div className="flex flex-wrap gap-1.5 justify-center pt-1">
                {(selectedProject ? [
                  `Explain the architecture of ${selectedProject.title}`,
                  `Find bugs and suggest fixes`,
                  `What improvements would you suggest?`,
                  `Write a summary of this project`,
                ] : [
                  "Explain the project structure",
                  "Find and fix bugs in routes.ts",
                  "Add error handling to the API",
                  "Write tests for the backup module",
                ]).map((suggestion) => (
                  <button
                    key={suggestion}
                    onClick={() => { setInput(suggestion); textareaRef.current?.focus(); }}
                    className="text-[10px] px-2 py-1 rounded-full border border-[#313244] text-[#a6adc8] hover:text-[#cdd6f4] hover:border-purple-500/30 transition-colors"
                    data-testid={`button-suggestion-${suggestion.slice(0, 20).replace(/\s/g, "-")}`}
                  >
                    {suggestion}
                  </button>
                ))}
              </div>
            </div>
          )}

          {messages.map((msg, i) => (
            <div key={i} className={`flex gap-2 ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
              {msg.role === "assistant" && (
                <div className="h-5 w-5 rounded-full bg-purple-500/20 flex items-center justify-center shrink-0 mt-0.5">
                  <Bot className="h-3 w-3 text-purple-400" />
                </div>
              )}
              <div
                className={`max-w-[85%] rounded-lg px-3 py-2 text-xs ${
                  msg.role === "user"
                    ? "bg-blue-600/20 text-[#cdd6f4] border border-blue-500/20"
                    : "bg-[#181825] text-[#cdd6f4] border border-[#313244]"
                }`}
                data-testid={`msg-${msg.role}-${i}`}
              >
                <pre className="whitespace-pre-wrap break-words font-mono leading-relaxed">{msg.content}</pre>
                {msg.streaming && (
                  <span className="inline-block w-1.5 h-3.5 bg-purple-400 animate-pulse ml-0.5 align-middle" />
                )}
              </div>
              {msg.role === "user" && (
                <div className="h-5 w-5 rounded-full bg-blue-500/20 flex items-center justify-center shrink-0 mt-0.5">
                  <User className="h-3 w-3 text-blue-400" />
                </div>
              )}
            </div>
          ))}
        </div>
      </ScrollArea>

      <div className="p-2 border-t border-[#313244] bg-[#181825]">
        <div className="flex items-end gap-2">
          <Textarea
            ref={textareaRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Ask Claude to code something... (Enter to send, Shift+Enter for newline)"
            className="flex-1 min-h-[36px] max-h-[120px] text-xs font-mono bg-[#1e1e2e] border-[#313244] text-[#cdd6f4] placeholder:text-[#6c7086] resize-none"
            disabled={isStreaming}
            data-testid="input-claude-code"
          />
          {isStreaming ? (
            <Button
              size="sm"
              variant="ghost"
              onClick={handleStop}
              className="h-9 px-3 text-red-400 hover:text-red-300 hover:bg-red-500/10"
              data-testid="button-claude-stop"
            >
              <Square className="h-3.5 w-3.5" />
            </Button>
          ) : (
            <Button
              size="sm"
              onClick={handleSubmit}
              disabled={!input.trim()}
              className="h-9 px-3 bg-purple-600 hover:bg-purple-700"
              data-testid="button-claude-send"
            >
              <Send className="h-3.5 w-3.5" />
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}

type RouterModel = {
  id: string;
  name: string;
  enabled: boolean;
  available?: boolean;
  costPer1kTokens: { input: number; output: number };
  speedRating: number;
  qualityRating: number;
  supportsStreaming: boolean;
  bridgeUrl?: string;
};

type RouterConfigData = {
  defaultMode: string;
  preferredModel: string;
  fallbackChain: string[];
  models: RouterModel[];
};

type RouterMessage = {
  role: "user" | "assistant";
  content: string;
  model?: string;
  timestamp: number;
  streaming?: boolean;
  tokens?: { input: number; output: number };
};

function AIRouterPanel({ selectedProject }: { selectedProject?: SelectedProject }) {
  const { toast } = useToast();
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<RouterMessage[]>([]);
  const [isStreaming, setIsStreaming] = useState(false);
  const [abortController, setAbortController] = useState<AbortController | null>(null);
  const [routingMode, setRoutingMode] = useState<string>("auto");
  const [manualModel, setManualModel] = useState<string>("");
  const [showConfig, setShowConfig] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const { data: config, refetch: refetchConfig } = useQuery<RouterConfigData>({
    queryKey: ["/api/workbench/router-config"],
  });

  const { data: usage, refetch: refetchUsage } = useQuery<Record<string, any>>({
    queryKey: ["/api/workbench/router-usage"],
  });

  const { data: bridgeStatus } = useQuery<any>({
    queryKey: ["/api/workbench/claude-bridge/status"],
    refetchInterval: 30000,
  });

  const updateConfigMutation = useMutation({
    mutationFn: async (updates: any) => {
      const res = await apiRequest("PATCH", "/api/workbench/router-config", updates);
      return res.json();
    },
    onSuccess: () => {
      refetchConfig();
      toast({ title: "Router config updated" });
    },
    onError: (e: any) => toast({ title: "Config update failed", description: e.message, variant: "destructive" }),
  });

  const deployBridgeMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/workbench/claude-bridge/deploy");
      return res.json();
    },
    onSuccess: (data) => {
      toast({ title: "Bridge deployed", description: data.message });
      queryClient.invalidateQueries({ queryKey: ["/api/workbench/claude-bridge/status"] });
    },
    onError: (e: any) => toast({ title: "Deploy failed", description: e.message, variant: "destructive" }),
  });

  const scrollToBottom = useCallback(() => {
    setTimeout(() => scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight }), 50);
  }, []);

  const handleSubmit = useCallback(async () => {
    if (!input.trim() || isStreaming) return;
    const prompt = input.trim();
    setInput("");

    const userMsg: RouterMessage = { role: "user", content: prompt, timestamp: Date.now() };
    const assistantMsg: RouterMessage = { role: "assistant", content: "", timestamp: Date.now(), streaming: true };
    setMessages(prev => [...prev, userMsg, assistantMsg]);
    setIsStreaming(true);
    scrollToBottom();

    const controller = new AbortController();
    setAbortController(controller);

    try {
      const body: Record<string, any> = { prompt, mode: routingMode, stream: true };
      if (routingMode === "manual" && manualModel) body.model = manualModel;
      if (selectedProject) {
        body.projectContext = {
          title: selectedProject.title,
          slug: selectedProject.slug,
          url: selectedProject.url,
          deploymentUrl: selectedProject.deploymentUrl,
          description: selectedProject.description,
          language: selectedProject.language,
        };
      }

      const res = await fetch("/api/workbench/route-prompt", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
        credentials: "include",
        signal: controller.signal,
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({ error: "Request failed" }));
        throw new Error(err.error || `HTTP ${res.status}`);
      }

      const reader = res.body?.getReader();
      const decoder = new TextDecoder();

      if (reader) {
        let buffer = "";
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split("\n");
          buffer = lines.pop() || "";

          for (const line of lines) {
            if (!line.startsWith("data: ")) continue;
            try {
              const data = JSON.parse(line.slice(6));
              if (data.type === "chunk") {
                setMessages(prev => {
                  const updated = [...prev];
                  const last = updated[updated.length - 1];
                  if (last?.streaming) {
                    updated[updated.length - 1] = { ...last, content: last.content + data.content, model: data.model };
                  }
                  return updated;
                });
                scrollToBottom();
              } else if (data.type === "model_selected") {
                setMessages(prev => {
                  const updated = [...prev];
                  const last = updated[updated.length - 1];
                  if (last?.streaming) {
                    const prefix = data.fallback ? `[Fallback: ${data.name}] ` : "";
                    if (prefix) {
                      updated[updated.length - 1] = { ...last, content: last.content + prefix, model: data.model };
                    } else {
                      updated[updated.length - 1] = { ...last, model: data.model };
                    }
                  }
                  return updated;
                });
              } else if (data.type === "done") {
                setMessages(prev => prev.map(m => m.streaming ? { ...m, streaming: false, tokens: data.tokens } : m));
                refetchUsage();
              } else if (data.type === "error") {
                setMessages(prev => prev.map(m => m.streaming ? { ...m, streaming: false, content: m.content + `\nError: ${data.content}` } : m));
              } else if (data.type === "fallback") {
                toast({ title: `${data.failedModel} failed`, description: `Falling back... (${data.error})` });
              }
            } catch {}
          }
        }
      }
    } catch (err: any) {
      if (err.name === "AbortError") return;
      setMessages(prev => prev.map(m => m.streaming ? { ...m, streaming: false, content: `Error: ${err.message}` } : m));
      toast({ title: "Router error", description: err.message, variant: "destructive" });
    } finally {
      setIsStreaming(false);
      setAbortController(null);
      setMessages(prev => prev.map(m => m.streaming ? { ...m, streaming: false } : m));
      scrollToBottom();
    }
  }, [input, isStreaming, routingMode, manualModel, selectedProject, scrollToBottom, toast, refetchUsage]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const availableModels = config?.models?.filter(m => m.available) || [];
  const totalCost = Object.values(usage || {}).reduce((sum: number, u: any) => sum + (u.totalCost || 0), 0);
  const totalRequests = Object.values(usage || {}).reduce((sum: number, u: any) => sum + (u.requests || 0), 0);

  const modelColors: Record<string, string> = {
    "claude-api": "text-orange-400",
    "gemini": "text-blue-400",
    "deepseek": "text-cyan-400",
    "claude-bridge": "text-purple-400",
  };

  const modelBadgeColors: Record<string, string> = {
    "claude-api": "border-orange-500/30 text-orange-400",
    "gemini": "border-blue-500/30 text-blue-400",
    "deepseek": "border-cyan-500/30 text-cyan-400",
    "claude-bridge": "border-purple-500/30 text-purple-400",
  };

  return (
    <div className="flex flex-col h-full bg-[#1e1e2e] rounded-lg overflow-hidden">
      <div className="flex items-center justify-between px-3 py-1.5 bg-[#181825] border-b border-[#313244]">
        <div className="flex items-center gap-2">
          <Zap className="h-3.5 w-3.5 text-amber-400" />
          <span className="text-xs text-[#cdd6f4] font-mono">AI Router</span>
          {availableModels.length > 0 && (
            <Badge variant="outline" className="text-[9px] h-4 border-emerald-500/30 text-emerald-400">{availableModels.length} models</Badge>
          )}
          {totalRequests > 0 && (
            <Badge variant="outline" className="text-[9px] h-4 border-amber-500/30 text-amber-400">${totalCost.toFixed(4)}</Badge>
          )}
        </div>
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="sm"
            className="h-6 px-2 text-[#6c7086] hover:text-[#cdd6f4]"
            onClick={() => setShowConfig(!showConfig)}
            data-testid="button-router-config"
          >
            <Activity className="h-3 w-3" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="h-6 px-2 text-[#6c7086] hover:text-[#cdd6f4]"
            onClick={() => setMessages([])}
            data-testid="button-clear-router"
          >
            <Trash2 className="h-3 w-3" />
          </Button>
        </div>
      </div>

      {showConfig && (
        <div className="px-3 py-2 border-b border-[#313244] bg-[#181825]/80 space-y-2">
          <div className="flex items-center gap-2">
            <span className="text-[10px] text-[#a6adc8] w-16">Mode:</span>
            <div className="flex gap-1 flex-1">
              {["auto", "cheapest", "fastest", "best", "manual"].map(m => (
                <button
                  key={m}
                  onClick={() => setRoutingMode(m)}
                  className={`text-[9px] px-1.5 py-0.5 rounded capitalize transition-colors ${
                    routingMode === m ? "bg-amber-600 text-white" : "text-[#6c7086] hover:text-[#cdd6f4] hover:bg-[#313244]"
                  }`}
                  data-testid={`button-mode-${m}`}
                >
                  {m}
                </button>
              ))}
            </div>
          </div>

          {routingMode === "manual" && (
            <div className="flex items-center gap-2">
              <span className="text-[10px] text-[#a6adc8] w-16">Model:</span>
              <select
                value={manualModel}
                onChange={e => setManualModel(e.target.value)}
                className="flex-1 h-6 text-[10px] px-1.5 rounded border border-[#313244] bg-[#1e1e2e] text-[#cdd6f4]"
                data-testid="select-manual-model"
              >
                <option value="">Auto-select</option>
                {availableModels.map(m => (
                  <option key={m.id} value={m.id}>{m.name} (${(m.costPer1kTokens.output * 1000).toFixed(2)}/1M out)</option>
                ))}
              </select>
            </div>
          )}

          <div className="space-y-1">
            <span className="text-[10px] text-[#a6adc8]">Models:</span>
            {config?.models?.map(m => (
              <div key={m.id} className="flex items-center justify-between px-1.5 py-1 rounded bg-[#1e1e2e]">
                <div className="flex items-center gap-2">
                  <span className={`h-1.5 w-1.5 rounded-full ${m.available ? "bg-emerald-500" : "bg-[#45475a]"}`} />
                  <span className={`text-[10px] ${modelColors[m.id] || "text-[#cdd6f4]"}`}>{m.name}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[8px] text-[#6c7086]">Q:{m.qualityRating} S:{m.speedRating}</span>
                  <span className="text-[8px] text-[#6c7086]">${m.costPer1kTokens.output}/1k</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    className={`h-4 px-1 text-[8px] ${m.enabled ? "text-emerald-400" : "text-[#45475a]"}`}
                    onClick={() => updateConfigMutation.mutate({ models: [{ id: m.id, enabled: !m.enabled }] })}
                    data-testid={`button-toggle-model-${m.id}`}
                  >
                    <Power className="h-2.5 w-2.5" />
                  </Button>
                </div>
              </div>
            ))}
          </div>

          {bridgeStatus && (
            <div className="flex items-center justify-between px-1.5 py-1 rounded bg-[#1e1e2e]">
              <div className="flex items-center gap-2">
                <span className={`h-1.5 w-1.5 rounded-full ${bridgeStatus.running ? "bg-emerald-500" : "bg-red-500"}`} />
                <span className="text-[10px] text-purple-400">Bridge</span>
                <span className="text-[8px] text-[#6c7086]">{bridgeStatus.running ? "Running" : bridgeStatus.error || "Offline"}</span>
              </div>
              <Button
                variant="ghost"
                size="sm"
                className="h-5 px-1.5 text-[8px] text-purple-400"
                onClick={() => deployBridgeMutation.mutate()}
                disabled={deployBridgeMutation.isPending}
                data-testid="button-deploy-bridge"
              >
                {deployBridgeMutation.isPending ? <Loader2 className="h-2.5 w-2.5 animate-spin" /> : <DownloadCloud className="h-2.5 w-2.5" />}
                Deploy
              </Button>
            </div>
          )}

          {usage && Object.keys(usage).length > 0 && (
            <div className="space-y-0.5">
              <span className="text-[10px] text-[#a6adc8]">Usage:</span>
              {Object.entries(usage).map(([model, stats]: [string, any]) => (
                <div key={model} className="flex items-center justify-between px-1.5 text-[9px]">
                  <span className={modelColors[model] || "text-[#cdd6f4]"}>{model}</span>
                  <span className="text-[#6c7086]">{stats.requests} req | ${stats.totalCost?.toFixed(4)}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      <ScrollArea className="flex-1 p-3" ref={scrollRef}>
        <div className="space-y-3">
          {messages.length === 0 && (
            <div className="text-center py-8 space-y-3">
              <div className="flex justify-center">
                <div className="h-10 w-10 rounded-full bg-amber-500/10 flex items-center justify-center">
                  <Zap className="h-5 w-5 text-amber-400" />
                </div>
              </div>
              <div>
                <p className="text-[#cdd6f4] text-sm font-medium">AI Model Router</p>
                <p className="text-[#6c7086] text-xs mt-1">
                  Routes prompts to the best AI model. {availableModels.length} model{availableModels.length !== 1 ? "s" : ""} available.
                </p>
                <div className="flex gap-1.5 justify-center mt-2">
                  {availableModels.map(m => (
                    <Badge key={m.id} variant="outline" className={`text-[8px] h-4 ${modelBadgeColors[m.id] || ""}`}>
                      {m.name}
                    </Badge>
                  ))}
                </div>
              </div>
              <div className="flex flex-wrap gap-1.5 justify-center pt-1">
                {["Compare AI model capabilities", "What are the cheapest options?", "Analyze this project's code quality"].map(s => (
                  <button
                    key={s}
                    onClick={() => { setInput(s); textareaRef.current?.focus(); }}
                    className="text-[10px] px-2 py-1 rounded-full border border-[#313244] text-[#a6adc8] hover:text-[#cdd6f4] hover:border-amber-500/30 transition-colors"
                    data-testid={`button-router-suggestion-${s.slice(0, 15).replace(/\s/g, "-")}`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}

          {messages.map((msg, i) => (
            <div key={i} className={`flex gap-2 ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
              {msg.role === "assistant" && (
                <div className="h-5 w-5 rounded-full bg-amber-500/20 flex items-center justify-center shrink-0 mt-0.5">
                  <Zap className="h-3 w-3 text-amber-400" />
                </div>
              )}
              <div className={`max-w-[85%] rounded-lg px-3 py-2 text-xs ${
                msg.role === "user"
                  ? "bg-blue-600/20 text-[#cdd6f4] border border-blue-500/20"
                  : "bg-[#181825] text-[#cdd6f4] border border-[#313244]"
              }`}>
                {msg.role === "assistant" && msg.model && (
                  <div className="flex items-center gap-1 mb-1">
                    <Badge variant="outline" className={`text-[8px] h-3.5 ${modelBadgeColors[msg.model] || ""}`}>
                      {config?.models?.find(m => m.id === msg.model)?.name || msg.model}
                    </Badge>
                    {msg.tokens && (
                      <span className="text-[8px] text-[#6c7086]">{msg.tokens.input}+{msg.tokens.output} tok</span>
                    )}
                  </div>
                )}
                <pre className="whitespace-pre-wrap break-words font-mono leading-relaxed">{msg.content}</pre>
                {msg.streaming && <span className="inline-block w-1.5 h-3.5 bg-amber-400 animate-pulse ml-0.5 align-middle" />}
              </div>
              {msg.role === "user" && (
                <div className="h-5 w-5 rounded-full bg-blue-500/20 flex items-center justify-center shrink-0 mt-0.5">
                  <User className="h-3 w-3 text-blue-400" />
                </div>
              )}
            </div>
          ))}
        </div>
      </ScrollArea>

      <div className="p-2 border-t border-[#313244] bg-[#181825]">
        <div className="flex items-center gap-1 mb-1.5">
          <Badge variant="outline" className="text-[8px] h-3.5 border-amber-500/30 text-amber-400">
            {routingMode}
          </Badge>
          {routingMode === "manual" && manualModel && (
            <Badge variant="outline" className={`text-[8px] h-3.5 ${modelBadgeColors[manualModel] || ""}`}>
              {config?.models?.find(m => m.id === manualModel)?.name || manualModel}
            </Badge>
          )}
          {selectedProject && (
            <Badge variant="outline" className="text-[8px] h-3.5 border-emerald-500/30 text-emerald-400 max-w-[150px] truncate">
              {selectedProject.title}
            </Badge>
          )}
        </div>
        <div className="flex items-end gap-2">
          <Textarea
            ref={textareaRef}
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Ask any AI model... (auto-routed)"
            className="flex-1 min-h-[36px] max-h-[120px] text-xs font-mono bg-[#1e1e2e] border-[#313244] text-[#cdd6f4] placeholder:text-[#6c7086] resize-none"
            disabled={isStreaming}
            data-testid="input-router-prompt"
          />
          {isStreaming ? (
            <Button
              size="sm"
              variant="ghost"
              onClick={() => { abortController?.abort(); setAbortController(null); setIsStreaming(false); setMessages(prev => prev.map(m => m.streaming ? { ...m, streaming: false, content: m.content + "\n\n[Stopped]" } : m)); }}
              className="h-9 px-3 text-red-400 hover:text-red-300 hover:bg-red-500/10"
              data-testid="button-router-stop"
            >
              <Square className="h-3.5 w-3.5" />
            </Button>
          ) : (
            <Button
              size="sm"
              onClick={handleSubmit}
              disabled={!input.trim()}
              className="h-9 px-3 bg-amber-600 hover:bg-amber-700"
              data-testid="button-router-send"
            >
              <Send className="h-3.5 w-3.5" />
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}

type CatalogSkill = {
  skillId: string;
  name: string;
  description: string;
  category: string;
  version: string;
  icon?: string;
  installed?: boolean;
  enabled?: boolean;
  source?: string;
};

type SkillCheckStatus = {
  lastCheck: string | null;
  nextCheck: string | null;
  intervalHours: number;
  newSkillsCount: number;
};

interface ClaudeSkill {
  id: string;
  name: string;
  description: string;
  category: string;
  source: string;
  path: string;
}

function SkillsPanel() {
  const { toast } = useToast();
  const [tab, setTab] = useState<"installed" | "catalog" | "claude">("installed");
  const [search, setSearch] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");

  const { data: installed = [], isLoading: loadingInstalled, refetch: refetchInstalled } = useQuery<any[]>({
    queryKey: ["/api/skills"],
  });

  const { data: catalog = [], isLoading: loadingCatalog, refetch: refetchCatalog } = useQuery<CatalogSkill[]>({
    queryKey: ["/api/skills/catalog"],
  });

  const { data: claudeSkills = [], isLoading: loadingClaude } = useQuery<ClaudeSkill[]>({
    queryKey: ["/api/skills/claude-skills"],
  });

  const { data: checkStatus, refetch: refetchStatus } = useQuery<SkillCheckStatus>({
    queryKey: ["/api/skills/check-status"],
  });

  const { data: newCount } = useQuery<{ count: number }>({
    queryKey: ["/api/skills/new-count"],
  });

  const installMutation = useMutation({
    mutationFn: async (skill: CatalogSkill) => {
      const res = await apiRequest("POST", "/api/skills", {
        skillId: skill.skillId,
        name: skill.name,
        description: skill.description,
        category: skill.category,
        version: skill.version,
      });
      return res.json();
    },
    onSuccess: (_, skill) => {
      toast({ title: "Skill installed", description: skill.name });
      queryClient.invalidateQueries({ queryKey: ["/api/skills"] });
      queryClient.invalidateQueries({ queryKey: ["/api/skills/catalog"] });
      queryClient.invalidateQueries({ queryKey: ["/api/skills/new-count"] });
    },
    onError: (e: any) => toast({ title: "Install failed", description: e.message, variant: "destructive" }),
  });

  const installAllMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/skills/install-all");
      return res.json();
    },
    onSuccess: (data) => {
      toast({ title: "All skills installed", description: `${data.installed || "All"} skills installed` });
      queryClient.invalidateQueries({ queryKey: ["/api/skills"] });
      queryClient.invalidateQueries({ queryKey: ["/api/skills/catalog"] });
      queryClient.invalidateQueries({ queryKey: ["/api/skills/new-count"] });
    },
    onError: (e: any) => toast({ title: "Install all failed", description: e.message, variant: "destructive" }),
  });

  const checkNowMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/skills/check-now");
      return res.json();
    },
    onSuccess: (data) => {
      toast({ title: "Skill check complete", description: data.message || `Found ${data.newSkills || 0} new skills` });
      refetchInstalled();
      refetchCatalog();
      refetchStatus();
      queryClient.invalidateQueries({ queryKey: ["/api/skills/new-count"] });
    },
    onError: (e: any) => toast({ title: "Check failed", description: e.message, variant: "destructive" }),
  });

  const toggleMutation = useMutation({
    mutationFn: async ({ id, enabled }: { id: string; enabled: boolean }) => {
      const res = await apiRequest("PATCH", `/api/skills/${id}`, { enabled });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/skills"] });
    },
    onError: (e: any) => toast({ title: "Toggle failed", description: e.message, variant: "destructive" }),
  });

  const sourceList = tab === "installed" ? installed : tab === "claude" ? claudeSkills : catalog;
  const categories = Array.from(new Set(
    sourceList.map((s: any) => s.category).filter(Boolean)
  )).sort();

  const items = sourceList.filter((s: any) => {
    const matchesSearch = !search ||
      s.name?.toLowerCase().includes(search.toLowerCase()) ||
      s.skillId?.toLowerCase().includes(search.toLowerCase()) ||
      s.id?.toLowerCase().includes(search.toLowerCase()) ||
      s.description?.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = categoryFilter === "all" || s.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  const uninstalledCount = catalog.filter((s: CatalogSkill) => !s.installed).length;

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between px-3 py-1.5 border-b">
        <div className="flex items-center gap-2">
          <Puzzle className="h-3.5 w-3.5 text-violet-400" />
          <span className="text-xs font-medium">Skills</span>
          <Badge variant="secondary" className="text-[9px] h-4" data-testid="badge-skills-installed">{installed.length}</Badge>
          {(newCount?.count ?? 0) > 0 && (
            <Badge variant="default" className="text-[9px] h-4 bg-violet-600" data-testid="badge-skills-new">{newCount?.count} new</Badge>
          )}
        </div>
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="sm"
            className="h-6 px-2 text-xs gap-1"
            onClick={() => checkNowMutation.mutate()}
            disabled={checkNowMutation.isPending}
            data-testid="button-skills-check-now"
          >
            {checkNowMutation.isPending ? <Loader2 className="h-3 w-3 animate-spin" /> : <RefreshCw className="h-3 w-3" />}
            Check New
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="h-6 px-2 text-xs gap-1 text-violet-400 hover:text-violet-300"
            onClick={() => installAllMutation.mutate()}
            disabled={installAllMutation.isPending || uninstalledCount === 0}
            data-testid="button-skills-install-all"
          >
            {installAllMutation.isPending ? <Loader2 className="h-3 w-3 animate-spin" /> : <DownloadCloud className="h-3 w-3" />}
            Install All
          </Button>
        </div>
      </div>

      <div className="px-2 py-1.5 border-b space-y-1.5">
        <div className="flex gap-1">
          <button
            onClick={() => setTab("installed")}
            className={`text-[10px] px-2 py-0.5 rounded font-medium transition-colors ${
              tab === "installed" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-muted"
            }`}
            data-testid="button-tab-installed"
          >
            Installed ({installed.length})
          </button>
          <button
            onClick={() => { setTab("claude"); setCategoryFilter("all"); }}
            className={`text-[10px] px-2 py-0.5 rounded font-medium transition-colors ${
              tab === "claude" ? "bg-blue-600 text-white" : "text-muted-foreground hover:bg-muted"
            }`}
            data-testid="button-tab-claude"
          >
            Claude ({claudeSkills.length})
          </button>
          <button
            onClick={() => setTab("catalog")}
            className={`text-[10px] px-2 py-0.5 rounded font-medium transition-colors ${
              tab === "catalog" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-muted"
            }`}
            data-testid="button-tab-catalog"
          >
            Catalog ({catalog.length})
            {uninstalledCount > 0 && (
              <span className="ml-1 text-[8px] bg-violet-600 text-white px-1 rounded-full">{uninstalledCount}</span>
            )}
          </button>
        </div>
        <div className="flex gap-1">
          <div className="relative flex-1">
            <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-3 w-3 text-muted-foreground" />
            <Input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search skills..."
              className="h-6 text-[10px] pl-7"
              data-testid="input-search-skills"
            />
          </div>
          <select
            value={categoryFilter}
            onChange={e => setCategoryFilter(e.target.value)}
            className="h-6 text-[10px] px-1.5 rounded border bg-background text-foreground"
            data-testid="select-skill-category"
          >
            <option value="all">All</option>
            {categories.map(c => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        </div>
      </div>

      {checkStatus && (
        <div className="px-3 py-1 border-b bg-muted/30 flex items-center justify-between">
          <div className="flex items-center gap-2 text-[9px] text-muted-foreground">
            <Clock className="h-2.5 w-2.5" />
            <span>Last check: {checkStatus.lastCheck ? new Date(checkStatus.lastCheck).toLocaleString() : "never"}</span>
          </div>
          <span className="text-[9px] text-muted-foreground">Every {checkStatus.intervalHours}h</span>
        </div>
      )}

      <ScrollArea className="flex-1">
        <div className="p-1.5 space-y-0.5">
          {((tab === "installed" && loadingInstalled) || (tab === "catalog" && loadingCatalog) || (tab === "claude" && loadingClaude)) ? (
            Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-12 rounded-md" />)
          ) : items.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Puzzle className="h-6 w-6 mx-auto mb-2 opacity-40" />
              <p className="text-xs">{search ? "No matching skills" : "No skills found"}</p>
            </div>
          ) : (
            items.map((skill: any) => {
              const isInstalled = tab === "installed" || skill.installed;
              const isClaude = tab === "claude";
              const sourceColor = skill.source === "replit" ? "text-blue-400 border-blue-500/30" :
                skill.source === "replit-secondary" ? "text-cyan-400 border-cyan-500/30" :
                skill.source === "mcp" ? "text-amber-400 border-amber-500/30" :
                skill.source === "agent" ? "text-emerald-400 border-emerald-500/30" :
                "text-muted-foreground";
              const sourceLabel = skill.source === "replit" ? "Core" :
                skill.source === "replit-secondary" ? "Secondary" :
                skill.source === "mcp" ? "MCP" :
                skill.source === "agent" ? "Agent" : "";
              const iconBg = isClaude ? "bg-blue-500/10" : "bg-violet-500/10";
              const iconColor = isClaude ? "text-blue-400" : "text-violet-400";
              return (
                <div
                  key={skill.skillId || skill.id}
                  className="rounded-md border px-2.5 py-2 hover:bg-muted/40 transition-colors group"
                  data-testid={`skill-card-${skill.skillId || skill.id}`}
                >
                  <div className="flex items-start gap-2">
                    <div className={`h-7 w-7 rounded-md ${iconBg} flex items-center justify-center shrink-0 mt-0.5`}>
                      {isClaude ? <Sparkles className={`h-3.5 w-3.5 ${iconColor}`} /> : <Puzzle className={`h-3.5 w-3.5 ${iconColor}`} />}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-medium truncate">{skill.name}</span>
                        {skill.version && <Badge variant="outline" className="text-[8px] h-3.5 px-1">{skill.version}</Badge>}
                        {skill.source === "clawhub" && <Badge variant="outline" className="text-[8px] h-3.5 px-1 border-blue-500/30 text-blue-400">ClawHub</Badge>}
                        {isClaude && sourceLabel && (
                          <Badge variant="outline" className={`text-[8px] h-3.5 px-1 ${sourceColor}`}>{sourceLabel}</Badge>
                        )}
                      </div>
                      <p className="text-[10px] text-muted-foreground truncate mt-0.5">{skill.description}</p>
                      <div className="flex items-center gap-1.5 mt-1">
                        {skill.category && !isClaude && (
                          <Badge variant="outline" className="text-[8px] h-3.5 px-1">{skill.category}</Badge>
                        )}
                        {isClaude && skill.path && (
                          <span className="text-[9px] text-muted-foreground font-mono truncate">{skill.path}</span>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      {tab === "installed" ? (
                        <Button
                          variant="ghost"
                          size="sm"
                          className={`h-6 px-2 text-[10px] gap-1 ${skill.enabled !== false ? "text-emerald-500" : "text-muted-foreground"}`}
                          onClick={() => toggleMutation.mutate({ id: skill.skillId || skill.id, enabled: skill.enabled === false })}
                          disabled={toggleMutation.isPending}
                          data-testid={`button-toggle-${skill.skillId || skill.id}`}
                        >
                          <Power className="h-3 w-3" />
                          {skill.enabled !== false ? "On" : "Off"}
                        </Button>
                      ) : isClaude ? (
                        <Badge variant="outline" className="text-[9px] h-5 text-blue-400 border-blue-500/30">
                          <CheckCircle2 className="h-2.5 w-2.5 mr-1" />
                          Active
                        </Badge>
                      ) : isInstalled ? (
                        <Badge variant="outline" className="text-[9px] h-5 text-emerald-500 border-emerald-500/30">
                          <CheckCircle2 className="h-2.5 w-2.5 mr-1" />
                          Installed
                        </Badge>
                      ) : (
                        <Button
                          variant="outline"
                          size="sm"
                          className="h-6 px-2 text-[10px] gap-1 text-violet-400 border-violet-500/30 hover:bg-violet-500/10"
                          onClick={() => installMutation.mutate(skill)}
                          disabled={installMutation.isPending}
                          data-testid={`button-install-${skill.skillId}`}
                        >
                          {installMutation.isPending ? <Loader2 className="h-3 w-3 animate-spin" /> : <Download className="h-3 w-3" />}
                          Install
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </ScrollArea>
    </div>
  );
}

type CodeReviewResult = {
  review: {
    overallGrade: string;
    overallSummary: string;
    issues: { severity: string; category: string; file: string; line: string | null; title: string; detail: string; suggestion: string }[];
    securityAudit: { score: number; findings: string[]; recommendations: string[] };
    performanceNotes: string[];
    architectureInsights: string[];
    bestPractices: string[];
  };
  meta: { projectSlug: string; filesScanned: number; filesReviewed: string[] };
  reviewedAt: string;
};

function CodeReviewPanel({ project, onClose }: { project: ReplitProject; onClose: () => void }) {
  const { toast } = useToast();
  const [filterSeverity, setFilterSeverity] = useState<string>("all");
  const [filterCategory, setFilterCategory] = useState<string>("all");
  const [expandedIssue, setExpandedIssue] = useState<number | null>(null);

  const reviewMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/workbench/code-review", {
        projectSlug: project.slug,
        projectTitle: project.title,
        projectUrl: project.url,
        language: project.language,
      });
      return res.json() as Promise<CodeReviewResult>;
    },
    onError: (e: Error) => toast({ title: "Review failed", description: e.message, variant: "destructive" }),
  });

  useEffect(() => {
    reviewMutation.mutate();
  }, [project.id]);

  const review = reviewMutation.data?.review;
  const meta = reviewMutation.data?.meta;

  const severityColor = (s: string) => {
    if (s === "critical") return "text-red-400 bg-red-500/10 border-red-500/30";
    if (s === "warning") return "text-amber-400 bg-amber-500/10 border-amber-500/30";
    return "text-blue-400 bg-blue-500/10 border-blue-500/30";
  };

  const severityIcon = (s: string) => {
    if (s === "critical") return <XCircle className="h-3.5 w-3.5 text-red-400" />;
    if (s === "warning") return <AlertTriangle className="h-3.5 w-3.5 text-amber-400" />;
    return <CheckCircle2 className="h-3.5 w-3.5 text-blue-400" />;
  };

  const gradeColor = (g: string) => {
    if (g === "A") return "text-emerald-400 border-emerald-500/40 bg-emerald-500/10";
    if (g === "B") return "text-blue-400 border-blue-500/40 bg-blue-500/10";
    if (g === "C") return "text-amber-400 border-amber-500/40 bg-amber-500/10";
    return "text-red-400 border-red-500/40 bg-red-500/10";
  };

  const filteredIssues = (review?.issues || []).filter(i => {
    if (filterSeverity !== "all" && i.severity !== filterSeverity) return false;
    if (filterCategory !== "all" && i.category !== filterCategory) return false;
    return true;
  });

  const categories = [...new Set((review?.issues || []).map(i => i.category))];

  if (reviewMutation.isPending) {
    return (
      <div className="flex flex-col items-center justify-center h-full gap-4 bg-slate-950 p-6">
        <Loader2 className="h-8 w-8 animate-spin text-purple-400" />
        <div className="text-center">
          <p className="text-sm font-medium text-purple-300">Reviewing {project.title}...</p>
          <p className="text-xs text-muted-foreground mt-1">Scanning files, analyzing patterns, checking security</p>
        </div>
      </div>
    );
  }

  if (!review) {
    return (
      <div className="flex flex-col items-center justify-center h-full gap-3 bg-slate-950 p-6">
        <XCircle className="h-6 w-6 text-red-400" />
        <p className="text-sm text-red-300">Review failed to generate</p>
        <Button size="sm" variant="outline" onClick={() => reviewMutation.mutate()} data-testid="button-retry-review">
          <RefreshCw className="h-3 w-3 mr-1" /> Retry
        </Button>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-slate-950">
      <div className="flex items-center justify-between px-4 py-2.5 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <Brain className="h-4 w-4 text-purple-400" />
          <span className="text-sm font-semibold text-slate-200">AI Code Review</span>
          <Badge variant="outline" className={`text-[10px] h-5 px-1.5 font-bold border ${gradeColor(review.overallGrade)}`}>
            Grade: {review.overallGrade}
          </Badge>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-[10px] text-muted-foreground">{meta?.filesScanned} files scanned</span>
          <Button
            variant="ghost"
            size="sm"
            className="h-6 w-6 p-0 text-muted-foreground hover:text-white"
            onClick={() => reviewMutation.mutate()}
            data-testid="button-rerun-review"
          >
            <RefreshCw className="h-3 w-3" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="h-6 w-6 p-0 text-muted-foreground hover:text-white"
            onClick={onClose}
            data-testid="button-close-review"
          >
            <XCircle className="h-3.5 w-3.5" />
          </Button>
        </div>
      </div>

      <ScrollArea className="flex-1">
        <div className="p-4 space-y-4">
          <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-3">
            <p className="text-xs text-slate-300 leading-relaxed">{review.overallSummary}</p>
          </div>

          <div className="grid grid-cols-3 gap-2">
            <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-2.5 text-center">
              <Shield className="h-4 w-4 mx-auto mb-1 text-cyan-400" />
              <p className="text-lg font-bold text-cyan-300">{review.securityAudit?.score || "--"}/10</p>
              <p className="text-[9px] text-muted-foreground">Security</p>
            </div>
            <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-2.5 text-center">
              <Bug className="h-4 w-4 mx-auto mb-1 text-red-400" />
              <p className="text-lg font-bold text-red-300">
                {(review.issues || []).filter(i => i.severity === "critical").length}
              </p>
              <p className="text-[9px] text-muted-foreground">Critical</p>
            </div>
            <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-2.5 text-center">
              <AlertTriangle className="h-4 w-4 mx-auto mb-1 text-amber-400" />
              <p className="text-lg font-bold text-amber-300">
                {(review.issues || []).filter(i => i.severity === "warning").length}
              </p>
              <p className="text-[9px] text-muted-foreground">Warnings</p>
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-slate-300">Issues ({filteredIssues.length})</span>
              <div className="flex gap-1">
                {["all", "critical", "warning", "info"].map(s => (
                  <button
                    key={s}
                    onClick={() => setFilterSeverity(s)}
                    className={`text-[9px] px-1.5 py-0.5 rounded capitalize ${
                      filterSeverity === s ? "bg-purple-600 text-white" : "text-muted-foreground hover:bg-slate-800"
                    }`}
                    data-testid={`button-filter-severity-${s}`}
                  >
                    {s}
                  </button>
                ))}
                {categories.length > 1 && (
                  <select
                    value={filterCategory}
                    onChange={(e) => setFilterCategory(e.target.value)}
                    className="text-[9px] bg-slate-800 border border-slate-700 rounded px-1 py-0.5 text-slate-300"
                    data-testid="select-filter-category"
                  >
                    <option value="all">all categories</option>
                    {categories.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                )}
              </div>
            </div>
            <div className="space-y-1.5">
              {filteredIssues.map((issue, idx) => (
                <div key={idx} className={`border rounded-lg overflow-hidden ${severityColor(issue.severity)}`}>
                  <button
                    className="w-full text-left px-3 py-2 flex items-start gap-2"
                    onClick={() => setExpandedIssue(expandedIssue === idx ? null : idx)}
                    data-testid={`button-issue-${idx}`}
                  >
                    {severityIcon(issue.severity)}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="text-[11px] font-medium">{issue.title}</span>
                        <Badge variant="outline" className="text-[8px] h-3.5 px-1 shrink-0">{issue.category}</Badge>
                      </div>
                      <div className="flex items-center gap-1.5 mt-0.5">
                        <FileCode className="h-2.5 w-2.5 text-muted-foreground shrink-0" />
                        <span className="text-[9px] text-muted-foreground truncate">{issue.file}</span>
                        {issue.line && <span className="text-[9px] text-muted-foreground">L{issue.line}</span>}
                      </div>
                    </div>
                    {expandedIssue === idx ? <ChevronUp className="h-3 w-3 shrink-0 mt-0.5" /> : <ChevronDown className="h-3 w-3 shrink-0 mt-0.5" />}
                  </button>
                  {expandedIssue === idx && (
                    <div className="px-3 pb-3 border-t border-current/10">
                      <p className="text-[10px] mt-2 text-slate-300 leading-relaxed">{issue.detail}</p>
                      {issue.suggestion && (
                        <div className="mt-2 bg-slate-950/60 rounded p-2 border border-slate-700">
                          <p className="text-[9px] text-emerald-400 font-medium mb-1">Suggestion:</p>
                          <pre className="text-[9px] text-slate-400 whitespace-pre-wrap font-mono">{issue.suggestion}</pre>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {review.securityAudit && (
            <div>
              <span className="text-xs font-semibold text-slate-300 flex items-center gap-1.5 mb-2">
                <Shield className="h-3.5 w-3.5 text-cyan-400" /> Security Audit
              </span>
              <div className="space-y-1">
                {review.securityAudit.findings?.map((f, i) => (
                  <div key={i} className="text-[10px] text-slate-400 flex items-start gap-1.5 bg-slate-900/40 rounded px-2 py-1.5">
                    <Target className="h-2.5 w-2.5 mt-0.5 text-cyan-500 shrink-0" />
                    {f}
                  </div>
                ))}
                {review.securityAudit.recommendations?.map((r, i) => (
                  <div key={i} className="text-[10px] text-emerald-400/80 flex items-start gap-1.5 bg-emerald-500/5 rounded px-2 py-1.5 border border-emerald-500/10">
                    <CheckCircle2 className="h-2.5 w-2.5 mt-0.5 shrink-0" />
                    {r}
                  </div>
                ))}
              </div>
            </div>
          )}

          {review.performanceNotes?.length > 0 && (
            <div>
              <span className="text-xs font-semibold text-slate-300 flex items-center gap-1.5 mb-2">
                <Zap className="h-3.5 w-3.5 text-amber-400" /> Performance
              </span>
              <div className="space-y-1">
                {review.performanceNotes.map((n, i) => (
                  <div key={i} className="text-[10px] text-slate-400 bg-slate-900/40 rounded px-2 py-1.5">{n}</div>
                ))}
              </div>
            </div>
          )}

          {review.architectureInsights?.length > 0 && (
            <div>
              <span className="text-xs font-semibold text-slate-300 flex items-center gap-1.5 mb-2">
                <Code2 className="h-3.5 w-3.5 text-purple-400" /> Architecture
              </span>
              <div className="space-y-1">
                {review.architectureInsights.map((a, i) => (
                  <div key={i} className="text-[10px] text-slate-400 bg-slate-900/40 rounded px-2 py-1.5">{a}</div>
                ))}
              </div>
            </div>
          )}

          {review.bestPractices?.length > 0 && (
            <div>
              <span className="text-xs font-semibold text-slate-300 flex items-center gap-1.5 mb-2">
                <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" /> Best Practices
              </span>
              <div className="space-y-1">
                {review.bestPractices.map((b, i) => (
                  <div key={i} className="text-[10px] text-slate-400 bg-slate-900/40 rounded px-2 py-1.5">{b}</div>
                ))}
              </div>
            </div>
          )}

          {meta?.filesReviewed && (
            <div>
              <span className="text-xs font-semibold text-slate-300 flex items-center gap-1.5 mb-2">
                <FolderTree className="h-3.5 w-3.5 text-slate-400" /> Files Reviewed ({meta.filesReviewed.length})
              </span>
              <div className="flex flex-wrap gap-1">
                {meta.filesReviewed.map((f, i) => (
                  <Badge key={i} variant="outline" className="text-[8px] text-slate-400 border-slate-700">{f}</Badge>
                ))}
              </div>
            </div>
          )}
        </div>
      </ScrollArea>
    </div>
  );
}

const PANELS = [
  { id: "claude", label: "Claude Code", icon: Sparkles, component: ClaudeCodePanel },
  { id: "shell", label: "Shell", icon: Terminal, component: ShellPanel },
  { id: "files", label: "Files", icon: FolderTree, component: FileExplorerPanel },
  { id: "preview", label: "Preview", icon: Eye, component: PreviewPanel },
  { id: "git", label: "Git", icon: GitBranch, component: GitPanel },
  { id: "activity", label: "Agent Activity", icon: Bot, component: AgentActivityPanel },
  { id: "database", label: "Database", icon: Database, component: DatabasePanel },
  { id: "security", label: "Security", icon: Shield, component: SecurityPanel },
  { id: "env", label: "Env Vars", icon: Key, component: EnvPanel },
  { id: "process", label: "Process", icon: Activity, component: ProcessPanel },
  { id: "skills", label: "Skills", icon: Puzzle, component: SkillsPanel },
  { id: "router", label: "AI Router", icon: Zap, component: AIRouterPanel },
] as const;

type PanelId = typeof PANELS[number]["id"];

type ReplitProject = {
  id: string;
  slug: string;
  title: string;
  description: string | null;
  url: string | null;
  deploymentUrl: string | null;
  language: string | null;
  isPrivate: boolean | null;
  status: string | null;
  deploymentStatus: string | null;
  tags: string[] | null;
};

function ProjectSidebar({
  selectedProject,
  onSelectProject,
  collapsed,
  onToggleCollapse,
  onReview,
}: {
  selectedProject: SelectedProject;
  onSelectProject: (p: SelectedProject) => void;
  collapsed: boolean;
  onToggleCollapse: () => void;
  onReview: (p: ReplitProject) => void;
}) {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");

  const { data: projects = [], isLoading } = useQuery<ReplitProject[]>({
    queryKey: ["/api/replit-projects"],
  });

  const filtered = projects.filter(p => {
    const matchesSearch = !search || p.title.toLowerCase().includes(search.toLowerCase()) ||
      p.slug.toLowerCase().includes(search.toLowerCase()) ||
      (p.description && p.description.toLowerCase().includes(search.toLowerCase()));
    const matchesStatus = statusFilter === "all" || p.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  if (collapsed) {
    return (
      <div className="w-10 border-r bg-muted/20 flex flex-col items-center py-2 gap-1">
        <Button
          variant="ghost"
          size="sm"
          className="h-7 w-7 p-0"
          onClick={onToggleCollapse}
          data-testid="button-expand-projects"
        >
          <PanelLeft className="h-3.5 w-3.5" />
        </Button>
        <Separator className="my-1 w-6" />
        <ScrollArea className="flex-1 w-full">
          <div className="flex flex-col items-center gap-1 px-1">
            {projects.slice(0, 20).map(p => (
              <button
                key={p.id}
                onClick={() => onSelectProject(selectedProject?.id === p.id ? null : p)}
                className={`h-7 w-7 rounded flex items-center justify-center text-[9px] font-bold transition-colors ${
                  selectedProject?.id === p.id
                    ? "bg-purple-600 text-white"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground"
                }`}
                title={p.title}
                data-testid={`button-project-icon-${p.id}`}
              >
                {p.title.charAt(0).toUpperCase()}
              </button>
            ))}
          </div>
        </ScrollArea>
      </div>
    );
  }

  return (
    <div className="w-64 border-r bg-muted/10 flex flex-col min-h-0">
      <div className="flex items-center justify-between px-3 py-2 border-b">
        <div className="flex items-center gap-2">
          <Code2 className="h-3.5 w-3.5 text-muted-foreground" />
          <span className="text-xs font-semibold">Projects</span>
          <Badge variant="secondary" className="text-[9px] h-4">{projects.length}</Badge>
        </div>
        <Button
          variant="ghost"
          size="sm"
          className="h-6 w-6 p-0"
          onClick={onToggleCollapse}
          data-testid="button-collapse-projects"
        >
          <PanelLeftClose className="h-3.5 w-3.5" />
        </Button>
      </div>

      <div className="px-2 py-2 space-y-2 border-b">
        <div className="relative">
          <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-3 w-3 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search projects..."
            className="h-7 text-xs pl-7"
            data-testid="input-search-projects"
          />
        </div>
        <div className="flex gap-1">
          {["all", "active", "paused", "completed"].map(s => (
            <button
              key={s}
              onClick={() => setStatusFilter(s)}
              className={`text-[9px] px-1.5 py-0.5 rounded capitalize transition-colors ${
                statusFilter === s ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-muted"
              }`}
              data-testid={`button-filter-${s}`}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      <ScrollArea className="flex-1">
        <div className="p-1.5 space-y-0.5">
          {isLoading ? (
            Array.from({ length: 5 }).map((_, i) => (
              <Skeleton key={i} className="h-14 rounded-md" />
            ))
          ) : filtered.length === 0 ? (
            <div className="text-center py-6 text-muted-foreground">
              <Code2 className="h-6 w-6 mx-auto mb-2 opacity-40" />
              <p className="text-xs">{search ? "No matching projects" : "No projects found"}</p>
            </div>
          ) : (
            filtered.map(p => {
              const isSelected = selectedProject?.id === p.id;
              return (
                <button
                  key={p.id}
                  onClick={() => onSelectProject(isSelected ? null : p)}
                  className={`w-full text-left rounded-md px-2.5 py-2 transition-all group ${
                    isSelected
                      ? "bg-purple-600/15 border border-purple-500/30 ring-1 ring-purple-500/20"
                      : "hover:bg-muted/60 border border-transparent"
                  }`}
                  data-testid={`button-project-${p.id}`}
                >
                  <div className="flex items-start gap-2">
                    <div className={`h-6 w-6 rounded flex items-center justify-center shrink-0 text-[10px] font-bold mt-0.5 ${
                      isSelected ? "bg-purple-600 text-white" : "bg-muted text-muted-foreground"
                    }`}>
                      {p.title.charAt(0).toUpperCase()}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5">
                        <span className={`text-xs font-medium truncate ${isSelected ? "text-purple-300" : ""}`}>
                          {p.title}
                        </span>
                        {p.isPrivate && <Lock className="h-2.5 w-2.5 text-muted-foreground shrink-0" />}
                      </div>
                      {p.description && (
                        <p className="text-[10px] text-muted-foreground truncate mt-0.5">{p.description}</p>
                      )}
                      <div className="flex items-center gap-1.5 mt-1">
                        {p.language && (
                          <Badge variant="outline" className="text-[8px] h-3.5 px-1">{p.language}</Badge>
                        )}
                        {p.deploymentStatus === "healthy" && (
                          <span className="flex items-center gap-0.5 text-[8px] text-emerald-500">
                            <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
                            live
                          </span>
                        )}
                        {p.deploymentUrl && (
                          <a
                            href={p.deploymentUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            onClick={(e) => e.stopPropagation()}
                            className="opacity-0 group-hover:opacity-100 transition-opacity"
                            data-testid={`link-deploy-${p.id}`}
                          >
                            <ExternalLink className="h-2.5 w-2.5 text-muted-foreground hover:text-foreground" />
                          </a>
                        )}
                      </div>
                    </div>
                  </div>
                </button>
              );
            })
          )}
        </div>
      </ScrollArea>

      {selectedProject && (
        <div className="px-3 py-2 border-t bg-purple-600/5 space-y-1.5">
          <div className="flex items-center gap-2">
            <Sparkles className="h-3 w-3 text-purple-400 shrink-0" />
            <span className="text-[10px] text-purple-300 truncate">
              Claude working on: <span className="font-medium">{selectedProject.title}</span>
            </span>
          </div>
          <Button
            size="sm"
            variant="outline"
            className="w-full h-7 text-[10px] bg-purple-600/10 border-purple-500/30 text-purple-300 hover:bg-purple-600/20 hover:text-purple-200"
            onClick={(e) => { e.stopPropagation(); onReview(selectedProject); }}
            data-testid="button-ai-review"
          >
            <Brain className="h-3 w-3 mr-1" /> AI Code Review
          </Button>
        </div>
      )}
    </div>
  );
}

export default function ClaudeWorkbench() {
  const [layout, setLayout] = useState<"split" | "full">("split");
  const [leftPanel, setLeftPanel] = useState<PanelId>("claude");
  const [rightPanel, setRightPanel] = useState<PanelId>("files");
  const [bottomPanel, setBottomPanel] = useState<PanelId>("shell");
  const [bottomRightPanel, setBottomRightPanel] = useState<PanelId>("git");
  const [showBottom, setShowBottom] = useState(false);
  const [selectedProject, setSelectedProject] = useState<SelectedProject>(null);
  const [projectSidebarCollapsed, setProjectSidebarCollapsed] = useState(false);
  const [reviewProject, setReviewProject] = useState<ReplitProject | null>(null);

  const renderPanel = (panelId: PanelId) => {
    const panel = PANELS.find(p => p.id === panelId);
    if (!panel) return null;
    const Component = panel.component;
    if (panelId === "claude") {
      return <ClaudeCodePanel selectedProject={selectedProject} />;
    }
    if (panelId === "preview") {
      return <PreviewPanel selectedProject={selectedProject} />;
    }
    if (panelId === "router") {
      return <AIRouterPanel selectedProject={selectedProject} />;
    }
    return <Component />;
  };

  const PanelSelector = ({ value, onChange, exclude }: { value: PanelId; onChange: (v: PanelId) => void; exclude?: PanelId[] }) => (
    <div className="flex items-center gap-0.5 overflow-x-auto">
      {PANELS.filter(p => !exclude || !exclude.includes(p.id)).map(p => {
        const Icon = p.icon;
        return (
          <button
            key={p.id}
            onClick={() => onChange(p.id)}
            className={`flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] whitespace-nowrap transition-colors ${
              value === p.id ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-muted hover:text-foreground"
            }`}
            data-testid={`button-panel-${p.id}`}
          >
            <Icon className="h-3 w-3" />
            {p.label}
          </button>
        );
      })}
    </div>
  );

  return (
    <div className="flex flex-col h-[calc(100vh-3.5rem)]">
      <div className="flex items-center justify-between px-4 py-2 border-b bg-background/95 backdrop-blur">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div className="h-6 w-6 rounded bg-gradient-to-br from-orange-500 to-amber-600 flex items-center justify-center">
              <Terminal className="h-3.5 w-3.5 text-white" />
            </div>
            <h1 className="text-base font-semibold tracking-tight" data-testid="text-workbench-title">Claude Workbench</h1>
          </div>
          <Badge variant="outline" className="text-[10px]">IDE</Badge>
          {selectedProject && (
            <Badge variant="outline" className="text-[10px] border-purple-500/30 text-purple-400" data-testid="badge-header-project">
              <Code2 className="h-3 w-3 mr-1" />
              {selectedProject.title}
            </Badge>
          )}
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant={showBottom ? "default" : "outline"}
            size="sm"
            className="h-7 text-xs"
            onClick={() => setShowBottom(!showBottom)}
            data-testid="button-toggle-bottom"
          >
            {showBottom ? "Hide Bottom" : "Show Bottom"}
          </Button>
        </div>
      </div>

      <div className="flex-1 flex min-h-0">
        <ProjectSidebar
          selectedProject={selectedProject}
          onSelectProject={setSelectedProject}
          collapsed={projectSidebarCollapsed}
          onToggleCollapse={() => setProjectSidebarCollapsed(!projectSidebarCollapsed)}
          onReview={(p) => setReviewProject(p)}
        />

        {reviewProject && (
          <div className="w-[380px] border-r min-h-0 flex flex-col">
            <CodeReviewPanel project={reviewProject} onClose={() => setReviewProject(null)} />
          </div>
        )}

        <div className="flex-1 flex flex-col min-h-0 min-w-0">
          <div className={`flex min-h-0 ${showBottom ? "h-[55%]" : "flex-1"}`}>
            <div className="flex-1 flex flex-col border-r min-w-0">
              <div className="px-2 py-1 border-b bg-muted/30">
                <PanelSelector value={leftPanel} onChange={setLeftPanel} />
              </div>
              <div className="flex-1 min-h-0 overflow-hidden">
                {renderPanel(leftPanel)}
              </div>
            </div>
            <div className="flex-1 flex flex-col min-w-0">
              <div className="px-2 py-1 border-b bg-muted/30">
                <PanelSelector value={rightPanel} onChange={setRightPanel} />
              </div>
              <div className="flex-1 min-h-0 overflow-hidden">
                {renderPanel(rightPanel)}
              </div>
            </div>
          </div>

          {showBottom && (
            <>
              <div className="h-px bg-border" />
              <div className="h-[45%] flex min-h-0">
                <div className="flex-1 flex flex-col border-r min-w-0">
                  <div className="px-2 py-1 border-b bg-muted/30">
                    <PanelSelector value={bottomPanel} onChange={setBottomPanel} />
                  </div>
                  <div className="flex-1 min-h-0 overflow-hidden">
                    {renderPanel(bottomPanel)}
                  </div>
                </div>
                <div className="flex-1 flex flex-col min-w-0">
                  <div className="px-2 py-1 border-b bg-muted/30">
                    <PanelSelector value={bottomRightPanel} onChange={setBottomRightPanel} />
                  </div>
                  <div className="flex-1 min-h-0 overflow-hidden">
                    {renderPanel(bottomRightPanel)}
                  </div>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
